#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<conio.h>
typedef struct{int p_id;char p_name[30];float p_price;int p_stock;}product_t;
void menu(void);
void addproduct(FILE *fptr);
void displayproducts(FILE *fptr);
void billslip(FILE *fptr,FILE *fptr2,FILE *fptr3);
void updateproduct(FILE *fptr);
void clearproduct(FILE *fptr);
void deleteproduct(FILE *fptr);
void dailyreport(FILE *fptr);
void productfrequency(FILE *fptr);
void safe(FILE *fptr);
int main()
{   menu();
    int n,i;
    int t=0;
    FILE *fptr, *fptr2,*fptr3,*fptr4;
    fptr=fopen("products.txt","r+b");
    fptr2=fopen("amount.txt","r");
    fptr3=fopen("frequency.txt","a");
    fptr4=fopen("frequency.txt","r");

    if(fptr==NULL||fptr2==NULL||fptr3==NULL||fptr4==NULL)
    {
        printf("File not opened correctly");
        exit(1);
    }
    while(n!=0)
    {
        if(t!=0)system("cls");
    t=1;
    printf("\nMain Menu :\n\n***********************************************\n");
    printf("Press 1 To add products\n***********************************************\n");
    printf("press 2 to view products\n***********************************************\n");
    printf("Press 3 to genrate bill slip\n***********************************************\n");
    printf("Press 4 to Update Product\n***********************************************\n");
    printf("Press 5 to Clear all products\n***********************************************\n");
    printf("Press 6 To Delete products\n***********************************************\n");
    printf("Press 7 To Check Amount in safe\n***********************************************\n");
    printf("Press 8 To Genrate Reports\n***********************************************\n");




    printf("press 0 to exit\n***********************************************\n");
    scanf("%d",&n);


        if(n==1)
            {
                 addproduct(fptr);
            }
            else if(n==2)
            {
                    displayproducts(fptr);
                }
            else if(n==3)
                {
                    billslip(fptr,fptr2,fptr3);
                }
            else if(n==4)
                {
                    updateproduct(fptr);
                }
             else if(n==5)
                    clearproduct(fptr);
            else if(n==6)
                deleteproduct(fptr);
                else if(n==7)
                    safe(fptr2);
            else if(n==8)
            {   system("cls");
                printf("Following are the reports i can genrate for you\n\n***********************************************\n");
                printf("Press 1 To genrate daily sales report\n***********************************************\n");
                printf("Press 2 To genrate Product frequency Report\n***********************************************\n");
                printf("Press 0 to exit\n***********************************************\n");
                scanf("%d",&n);
                if(n==1)
                {
                     dailyreport(fptr4);

                }
                else if(n==2)
                    productfrequency(fptr4);
            }

     }
     printf("\nThank You very much have a good day");
     fclose(fptr);
    fclose(fptr2);
     fclose(fptr3);
     fclose(fptr4);

     return 0;

}
void menu(void)
{
    int n,i;
    do
    {
        system("cls");
    printf("\n\n\n\n\n\n\t\t\t\t\tWelcome User This is the login Page \n");
    printf("\n\n\t\t\t\t\t Name: ");
    char password[10] = {};
    char username[10]={};
    scanf("%s",username);
    if(strcmp(username,"Hammad")==0)
    {
        printf("\n\t\t\t\t\tPassword ");
        for(i=0;i<5;i++)
        {
            password[i]=_getch();
            printf("*");
            n=2;
         }
         if(strcmp(password,"dummy")==0)
            {
            n=1;
            }
        else
            {
                printf("\n\n\t\t\t\t\t\aWrong Password");
                printf("\n\n\t\t\t\t\tPress Enter to continue again");
                _getch();
                n=0;
            }
    }
else
{
 printf("\n\n\t\t\t\t\t\aWrong User name");
 _getch();
 printf("\n\n\t\t\t\t\tPress Enter key to continue again");
 n=0;
}


}while(n==0);
do
{
if(n==1)
{
    system("cls");
      printf("Welcome Owner,\n\nThis is the main menu Press Enter to see the functions i can do for you\n\n");
        printf("***********************************************\n");

}
}while(_getch()!='\r');
}
void addproduct(FILE *fptr)
{
    product_t product={0,"",0.0};
   int i,id,stock;
   float price;
   char name[10];
    do
    {
        system("cls");
    printf("\nWelcome Owner Enter The following information to add new product\n\n");
    printf("*******************************************************************\n");
    printf("\nEnter product id Between 0-100 = ");
    scanf("%d",&id);
    printf("\nEnter Product Name = ");
    scanf("%s",name);
    printf("\nEnter Product Price = ");
    scanf("%f",&price);
    printf("\nEnter Stock Quantity = ");
    scanf("%d",&stock);
    fseek(fptr,(id-1)*sizeof(product_t),SEEK_SET);
    fread(&product,sizeof(product_t),1,fptr);
    if(product.p_id==0)
    {
        product.p_id=id;
        strcpy(product.p_name,name);
    product.p_price=price;
    product.p_stock=stock;
        fseek(fptr,(id-1)*sizeof(product_t),SEEK_SET);

    fwrite(&product,sizeof(product_t),1,fptr);
    }
    else
    {
        printf("\nThis Code Already Exist Try a new one\n");
        //exit(1);
    }
    printf("\nPress  Enter  to add another product\nPress any other key to exit");
    }while(_getch()=='\r');


}
void displayproducts(FILE *fptr)
{
   char n;
   do
   {
       system("cls");
    printf("These are the products currently in our inventory\n\n");
    printf("************************************************************\n");
    printf("\tid\t|\tName\t|Price\t\t|Stocks\n");

    product_t product;
    while(!feof(fptr))
        {
            fread(&product,sizeof(product_t),1,fptr);
           if(product.p_id!=0)
            {
                    printf("\n\t%d\t|\t%s\t|%0.2f\t\t|   %d\t\n",product.p_id,product.p_name,product.p_price,product.p_stock);
            }
        }
        printf("\n********************************************************\n");
        printf("\n PRESS ENTER KEY TO CONTINUE");
   }while(_getch()!='\r');
       rewind(fptr);
}

void billslip(FILE *fptr,FILE *fptr2,FILE *fptr3)
{
    int t;

     system("cls");
     printf("Welcome Owner\n");
    printf("************************************************************\n");
    int key,total,quantity,cash,change,amount,sale,stock;
    char date[10];
    int id,k,i=0,n,total_z=0;
    int id_t[4],safe=0,countt=0;
    float price_t[20];
    char name_t[20][20];
    int quantity_t[20],total_t[20],count[20]={};
    int j=1;
    char name[100],c;
    float price;
    system("cls");
    printf("Enter Date in this format dd-mm-yyyy = ");
    scanf("%s",date);
    system("cls");
    do
    {
        system("cls");
    do
    {
    rewind(fptr);
    printf("\nEnter The Product Code ");
    scanf("%d",&key);
    printf("\nEnter quantity ");
    scanf("%d",&quantity);
    while(!feof(fptr))
    {
    product_t product;

     fread(&product,sizeof(product_t),1,fptr);

     if(product.p_id==key)
     {

         total=quantity*product.p_price;
         total_z=total_z+total;

         id_t[i]=product.p_id;

         price_t[i]=product.p_price;
        strcpy(name_t[i], product.p_name);

         total_t[i]=total;

         quantity_t[i]=quantity;
         sale=total_z;
         product.p_stock=product.p_stock-quantity;
         if(product.p_stock<0)
         {
             printf("\n Sorry! %s is out of stock \n",product.p_name);
             _getch();
             exit(1);
         }
         fprintf(fptr3,"%d %s %d %d %s\n",product.p_id,product.p_name,quantity,sale,date);
         fseek(fptr,(key-1)*sizeof(product_t),SEEK_SET);
         fwrite(&product,sizeof(product_t),1,fptr);
         i++;
         countt++;

            break;
         }
         if(feof(fptr))
         {
             if(product.p_id!=key)
             {
                 printf("\nproducts code is invalid\a");
                 _getch();
                 exit(1);


             }
         }

    }
   // i++;
    printf("\t\t\t\t\t\t*****************************************");
    printf("\n\t\t\t\t\t\t* Press ENTER TO Add Another Product    *\n\n\t\t\t\t\t\t* or any other Key to Genrate Bill slip *\n");
    printf("\t\t\t\t\t\t*****************************************");

    }while(_getch()=='\r');
    int z;
    for(z=0;z<countt;z++)
    {
        if(j==1)
         {
             system("cls");

             printf("\nBill Slip \n");
             printf("*********************************************************************************************************************\n");
             printf("Sr.No\t|\tid|\tProduct_Name\t|\tPrice\t|\tQuantity\t|\tTotal_price\n");

             j++;
         }
             printf("*********************************************************************************************************************\n");
             printf("%d\t|\t%d|\t%s\t\t|\t%0.2f\t|\t%d\t\t|\t%d \n",z+1,id_t[z],name_t[z],price_t[z],quantity_t[z],total_t[z]);
    }
    printf("*********************************************************************************************************************\n");
    printf("Total bill                                                                             = %d",total_z);
    printf("\n\nEnter amount given by customer                                                       =   ");
    scanf("%d",&cash);
    change=cash-total_z;
    fscanf(fptr2,"%d",&safe);
    printf("\nTotal safe = %d\n",safe);
    total_z=safe+total_z;
    fprintf(fptr2,"%d",total_z);
    printf("\nAmount to be returned to customer                                                     = %d\n",change);
    printf("\n*******************************************************************************************************\n");
    printf("\nPress Enter To Genrate another BILL SLIP\nPress any other key to exit");
    i=0;
    j=1;
    countt=0;
    total_z=0;
    _getch();
    }while(_getch()=='\r');
}

void updateproduct(FILE *fptr)
{
    int n,temp;

    do
    {
    system("cls");
    int id;
    product_t product={0,"",0.0,0};
    int i;
    printf("\nEnter product id to be updated = ");
    scanf("%d",&product.p_id);
    fseek(fptr,(product.p_id-1)*sizeof(product_t),SEEK_SET);
    fread(&product,sizeof(product_t),1,fptr);
    if(product.p_id==0)
    {   temp=0;
        printf("\nProduct id does not exist \a\n");
        break;
    }
    printf("\nEnter new Product Name = ");
    scanf("%s",product.p_name);
    printf("\nEnter new Product Price = ");
    scanf("%f",&product.p_price);
    printf("\nEnter Product Stocks = ");
    scanf("%d",&product.p_stock);
    fseek(fptr,(product.p_id-1)*sizeof(product_t),SEEK_SET);
   printf("\nProduct has been Updated Succefully\n");

    fwrite(&product,sizeof(product_t),1,fptr);
    printf("\n Press 0 to exit or 1 to update another product ");
    scanf("%d",&n);
    }while(n!=0);
    if(temp==0)
    {do
     {
        printf("\nPress ENTER key to go back to main menu \n\nThen press 2 to view all products in our inventory");
     }while(_getch()!='\r');
    }
    rewind(fptr);
}
void clearproduct(FILE *fptr)
{
    char n;
    system("cls");
    printf("Caution:\nPress Enter to delete ALL Products\nPress Anyother key to Exit ");
     while(_getch()=='\r')
    {
 do
 {
     system("cls");
    int id;
    product_t product={0,"",0.0,0};
    int i;

   for(i=0;i<100;i++)
    fwrite(&product,sizeof(product_t),1,fptr);
    printf("All Inventory is cleared\n");
    printf("*****************************************************************************");
     printf("\n\nPress Enter key to  go back to main menu ");
 }while(_getch()!='\r');
    }
}
void deleteproduct(FILE *fptr)
{
    int n;
    do
    {
        system("cls");
    product_t product={0,"",0.0,0};
    printf("\nEnter product id = ");
    scanf("%d",&product.p_id);
    fseek(fptr,(product.p_id-1)*sizeof(product_t),SEEK_SET);
    product.p_id=0;
    fwrite(&product,sizeof(product_t),1,fptr);
    printf("\nProduct has been deleted\n\n");
    printf("******************************************************************\nPress 0 to go back to Main Menu \nor 1 to delete another product \n");
    scanf("%d",&n);
    }while(n!=0);
}
void dailyreport(FILE *fptr)
{   system("cls");
    int sale,quantity,i=1,stock,id,total=0;
    char p_date[10];
    product_t product;
    char pdate[10] = {};
    char pdate2[10]={};
    char p_pdate2[10] = {};
    printf("Enter date(dd-mm-yyyy) to genrate daily report of sale ");
    scanf(" %s",pdate2);
    strcpy(p_pdate2, pdate2);
 do
    {
        rewind(fptr);
     while(!feof(fptr))
     {
         fscanf(fptr,"%d %s %d %d %s\n",&id,product.p_name,&stock,&sale,pdate);
            if(strcmp(p_pdate2, pdate)==0)
        {
            if(i==1)
            {
                printf("Following is the sale report of today \n*****************************************************************************\n");
                printf("\tid\t|\tName\t|   Quantity\t|\tSale\t| Date\n");
                i++;
            }
                printf("%10d\t| %10s\t| %10d\t| %10d\t| %10s\n",id,product.p_name,stock,sale,p_pdate2);
                total=total+sale;
        }
    }                printf("\n*****************************************************************************\n");
    printf("Total Sale of Today Till Now is = %d\n",total);
                    printf("\nPress Enter to continue again ");
       } while(_getch()!='\r');
}
void productfrequency(FILE *fptr)
{
    product_t product;
    int sale,quantity,total=0,j=1;
    float key;
    char date[10],name[12];
    do
    {
        rewind(fptr);
        system("cls");
        printf("Enter the product id to genrate report\n***************************************************************\n");
        scanf("%f",&key);
        system("cls");
    while(!feof(fptr))
    {

    fscanf(fptr,"%d %s %d %d %s\n",&product.p_id,product.p_name,&quantity,&sale,date);

    if(key==product.p_id)
        {
            if(j==1)
            {
                printf("Following is the sales of given product id = %d\n**************************************************************************************\n\tId\t|\tName\t|\tQuantity\t|\tSale\t|\tDate\t\n",product.p_id);
                j++;
            }
                printf("\n\t%d\t|\t%s\t|\t%d\t\t|\t%d\t|\t%s\t\n",product.p_id,product.p_name,quantity,sale,date);
                strcpy(name,product.p_name);

                total=total+sale;

        }
    }
    printf("___________________________________________________________________________________________\nTotal sale of '%s' till now is = %d\n",name,total);
    printf("************************************************\nPRESS ENTER KEY TO CONTINUE");
    }while(_getch()!='\r');
}
void safe(FILE *fptr)
{
    fptr = fopen("amount.txt", "r");
    system("cls");
    printf("************************************************************\n");
    int amount;
    fscanf(fptr,"%d", amount);
    printf("Total Amount in Safe is = %d\nPress Enter To continue", amount);
    printf("\n************************************************************\n");
    _getch();

    rewind(fptr);
}







